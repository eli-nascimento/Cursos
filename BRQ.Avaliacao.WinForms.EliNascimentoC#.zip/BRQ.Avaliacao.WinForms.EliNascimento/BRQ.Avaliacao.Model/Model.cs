﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BRQ.Avaliacao.Model
{
    ///<<summary///
    ///Objetivo: Classe Propriedades
    ///
    public class Model
    {
        public string p_campoA { get; set; }
        public string p_campoB { get; set; }
        public string p_campoC { get; set; }
        public string p_campoD { get; set; }
        public string p_campoE { get; set; }
        public string p_campoF { get; set; }
    }
}
