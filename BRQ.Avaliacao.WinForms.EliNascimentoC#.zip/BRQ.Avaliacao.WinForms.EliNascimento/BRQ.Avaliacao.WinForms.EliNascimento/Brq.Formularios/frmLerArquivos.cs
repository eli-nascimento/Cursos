﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using BRQ.Avaliacao;

namespace BRQ.Avaliacao.WinForms.EliNascimento
{
    public partial class frmLerArquivos : Form
    {
        public frmLerArquivos()
        {
            InitializeComponent();
        }
        #region | variaveis
        private string v_arquivoConteudo = string.Empty;
        private string v_arquivoCaminho = @"C:";
        private static string v_linha = String.Empty;
        private string v_TipoArquivo = "txt files (*.txt)|*.txt";
        private int segundos = 6000;
        private static string arquivoTxt = "resultado.txt";
        CancellationTokenSource parar = new CancellationTokenSource();
        CancellationToken token;
        #endregion
        #region | Eventos
        ///<<summary///
        ///Objetivo: Importa arquivo, inserir conteudo em Tabela e gerar dados de saida criando outro arquivo txt
        ///
        private void BtnSelecione_Click(object sender, EventArgs e)
        {
            try
            {
                using (OpenFileDialog openFileDialog = new OpenFileDialog())
                {
                    openFileDialog.InitialDirectory = v_arquivoCaminho;
                    openFileDialog.Filter = v_TipoArquivo;
                    openFileDialog.FilterIndex = 2;
                    openFileDialog.RestoreDirectory = true;
                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        //Seleciona caminho do arquivo
                        v_arquivoCaminho = openFileDialog.FileName;
                        string[] v_arquivoImportado = System.IO.File.ReadAllLines(v_arquivoCaminho);
                        //valida numero de linhas
                        foreach (string v_linha in v_arquivoImportado)
                        {
                            if (v_linha.Split(',').Length < 6)
                            {
                                MessageBox.Show("Numero de colunas invalido!");
                                return;
                            }
                        }
                        if (v_arquivoImportado.Length < 10)
                        {
                            MessageBox.Show("Numero de linhas invalido!");
                        }
                        else
                        {
                            TxtArquivoEntrada.Text = v_arquivoCaminho;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(v_arquivoConteudo, ex.Message + v_arquivoCaminho, MessageBoxButtons.OK);
            }
        }
        //Incia o processo
        private void TsbIniciar_Click(object sender, EventArgs e)
        {
            if (TxtArquivoEntrada.Text != string.Empty)
            {
                RtbLogExecucao.Text = string.Empty;
                Task tarefa = Task.Run(() =>
                {
                    LerArquivo();
                },
                token);
            }
            else
            {
                MessageBox.Show("Arquivo de importacao nao encontrado!");
            }
        }
        //Para o Importacao e gera arquivo de saida
        private void TsbParar_Click(object sender, EventArgs e)
        {
            Dao.Db Da = new Dao.Db();
            token = parar.Token;
            if (parar != null)
            {
                parar.Cancel();
                var LstDado = Da.SelecionarDados();
                CriarArquivo(LstDado, TxtDiretorioDeSaida.Text);
            }
        }
        #endregion
        #region | Metodos
        //Ler o conteudo do arquivo
        private void LerArquivo()
        {
            var fileStream = v_arquivoCaminho;
            Model.Model o_Dados = new Model.Model();
            List<Avaliacao.Model.Model> l_Dados = new List<Avaliacao.Model.Model>();
            Dao.Db Da = new Dao.Db();
            int cnt = 0;
            using (StreamReader reader = new StreamReader(fileStream))
            {
                while ((v_linha = reader.ReadLine()) != null)
                {
                    ExibirDados(Convert.ToString(v_linha));
                    if (cnt == 6)
                        cnt = 0;
                    o_Dados = new Model.Model();
                    string[] itemArray = v_linha.Split(',');
                    o_Dados.p_campoA = itemArray[cnt];
                    o_Dados.p_campoB = itemArray[cnt];
                    o_Dados.p_campoC = itemArray[cnt];
                    o_Dados.p_campoD = itemArray[cnt];
                    o_Dados.p_campoE = itemArray[cnt];
                    o_Dados.p_campoF = itemArray[cnt];
                    l_Dados.Add(o_Dados);
                    cnt++;
                    Thread.Sleep(segundos);
                }
                var resultado = Da.InserirDados(l_Dados);
                if (resultado == 1)
                    MessageBox.Show("Processo executado com sucesso!");
                else
                    MessageBox.Show("Processo executado com erro!");
            }
        }
        //Exibi os dados processo no form
        private void ExibirDados(string v_linha)
        {
            if (RtbLogExecucao.InvokeRequired)
            {
                RtbLogExecucao.Invoke(new Action<string>(ExibirDados), v_linha + "\n");
            }
            else
            {
                RtbLogExecucao.AppendText(v_linha + "\n");
            }
        }
        //Criar arquivo .txt de saida
        public static void CriarArquivo(List<Model.Model> o_Dados, string Caminho)
        {
            string nomeArquivo = @Caminho + arquivoTxt;
            StreamWriter wtr = new StreamWriter(nomeArquivo);
            for (int t = 0; t < o_Dados.Count; t++)
            {
                wtr.WriteLine(o_Dados[t].p_campoA + "," + o_Dados[t].p_campoB + "," + o_Dados[t].p_campoC + "," + o_Dados[t].p_campoD + "," + o_Dados[t].p_campoE + "," + o_Dados[t].p_campoF + ",");
            }
            wtr.Close();
        }
        #endregion
    }
}
