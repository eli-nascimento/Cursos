﻿namespace BRQ.Avaliacao.WinForms.EliNascimento
{
    partial class frmLerArquivos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLerArquivos));
            this.TxtArquivoEntrada = new System.Windows.Forms.TextBox();
            this.TxtDiretorioDeSaida = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.BtnSelecione = new System.Windows.Forms.Button();
            this.lblArquivoEntrada = new System.Windows.Forms.Label();
            this.lblDiretorioDeSaida = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.TsbIniciar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbParar = new System.Windows.Forms.ToolStripButton();
            this.lblLogExecucao = new System.Windows.Forms.Label();
            this.RtbLogExecucao = new System.Windows.Forms.RichTextBox();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // TxtArquivoEntrada
            // 
            this.TxtArquivoEntrada.BackColor = System.Drawing.SystemColors.Menu;
            this.TxtArquivoEntrada.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtArquivoEntrada.Location = new System.Drawing.Point(27, 87);
            this.TxtArquivoEntrada.Name = "TxtArquivoEntrada";
            this.TxtArquivoEntrada.Size = new System.Drawing.Size(543, 28);
            this.TxtArquivoEntrada.TabIndex = 0;
            // 
            // TxtDiretorioDeSaida
            // 
            this.TxtDiretorioDeSaida.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDiretorioDeSaida.Location = new System.Drawing.Point(26, 159);
            this.TxtDiretorioDeSaida.Name = "TxtDiretorioDeSaida";
            this.TxtDiretorioDeSaida.Size = new System.Drawing.Size(656, 28);
            this.TxtDiretorioDeSaida.TabIndex = 1;
            this.TxtDiretorioDeSaida.Text = "C:\\Temp\\";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // BtnSelecione
            // 
            this.BtnSelecione.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSelecione.Location = new System.Drawing.Point(576, 87);
            this.BtnSelecione.Name = "BtnSelecione";
            this.BtnSelecione.Size = new System.Drawing.Size(106, 25);
            this.BtnSelecione.TabIndex = 2;
            this.BtnSelecione.Text = "Selecione";
            this.BtnSelecione.UseVisualStyleBackColor = true;
            this.BtnSelecione.Click += new System.EventHandler(this.BtnSelecione_Click);
            // 
            // lblArquivoEntrada
            // 
            this.lblArquivoEntrada.AutoSize = true;
            this.lblArquivoEntrada.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArquivoEntrada.Location = new System.Drawing.Point(23, 64);
            this.lblArquivoEntrada.Name = "lblArquivoEntrada";
            this.lblArquivoEntrada.Size = new System.Drawing.Size(175, 20);
            this.lblArquivoEntrada.TabIndex = 3;
            this.lblArquivoEntrada.Text = "Arquivo de Entrada";
            // 
            // lblDiretorioDeSaida
            // 
            this.lblDiretorioDeSaida.AutoSize = true;
            this.lblDiretorioDeSaida.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiretorioDeSaida.Location = new System.Drawing.Point(23, 136);
            this.lblDiretorioDeSaida.Name = "lblDiretorioDeSaida";
            this.lblDiretorioDeSaida.Size = new System.Drawing.Size(164, 20);
            this.lblDiretorioDeSaida.TabIndex = 4;
            this.lblDiretorioDeSaida.Text = "Diretorio de Saida";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbIniciar,
            this.toolStripSeparator1,
            this.TsbParar});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(709, 27);
            this.toolStrip1.TabIndex = 5;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // TsbIniciar
            // 
            this.TsbIniciar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TsbIniciar.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TsbIniciar.Image = ((System.Drawing.Image)(resources.GetObject("TsbIniciar.Image")));
            this.TsbIniciar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbIniciar.Name = "TsbIniciar";
            this.TsbIniciar.Size = new System.Drawing.Size(68, 24);
            this.TsbIniciar.Text = "Iniciar";
            this.TsbIniciar.Click += new System.EventHandler(this.TsbIniciar_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // TsbParar
            // 
            this.TsbParar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TsbParar.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TsbParar.Image = ((System.Drawing.Image)(resources.GetObject("TsbParar.Image")));
            this.TsbParar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbParar.Name = "TsbParar";
            this.TsbParar.Size = new System.Drawing.Size(57, 24);
            this.TsbParar.Text = "Parar";
            this.TsbParar.Click += new System.EventHandler(this.TsbParar_Click);
            // 
            // lblLogExecucao
            // 
            this.lblLogExecucao.AutoSize = true;
            this.lblLogExecucao.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogExecucao.Location = new System.Drawing.Point(22, 216);
            this.lblLogExecucao.Name = "lblLogExecucao";
            this.lblLogExecucao.Size = new System.Drawing.Size(152, 20);
            this.lblLogExecucao.TabIndex = 6;
            this.lblLogExecucao.Text = "Log de Execução";
            // 
            // RtbLogExecucao
            // 
            this.RtbLogExecucao.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.RtbLogExecucao.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RtbLogExecucao.Location = new System.Drawing.Point(26, 239);
            this.RtbLogExecucao.Name = "RtbLogExecucao";
            this.RtbLogExecucao.Size = new System.Drawing.Size(656, 318);
            this.RtbLogExecucao.TabIndex = 7;
            this.RtbLogExecucao.Text = "";
            // 
            // frmLerArquivos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(709, 615);
            this.Controls.Add(this.RtbLogExecucao);
            this.Controls.Add(this.lblLogExecucao);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.lblDiretorioDeSaida);
            this.Controls.Add(this.lblArquivoEntrada);
            this.Controls.Add(this.BtnSelecione);
            this.Controls.Add(this.TxtDiretorioDeSaida);
            this.Controls.Add(this.TxtArquivoEntrada);
            this.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "frmLerArquivos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "...::: Leitor de Arquivos :::..";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtArquivoEntrada;
        private System.Windows.Forms.TextBox TxtDiretorioDeSaida;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button BtnSelecione;
        private System.Windows.Forms.Label lblArquivoEntrada;
        private System.Windows.Forms.Label lblDiretorioDeSaida;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton TsbIniciar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton TsbParar;
        private System.Windows.Forms.Label lblLogExecucao;
        public System.Windows.Forms.RichTextBox RtbLogExecucao;
    }
}

