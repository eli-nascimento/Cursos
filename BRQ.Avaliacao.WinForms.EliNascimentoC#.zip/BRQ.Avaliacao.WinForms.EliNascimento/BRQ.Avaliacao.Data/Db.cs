﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BRQ.Avaliacao.Model;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.ComponentModel;

namespace BRQ.Avaliacao.Dao
{
    ///<<summary///
    ///Objetivo: Classe CRUD banco de dados
    ///
    public class Db
    {
        public string ConnectionString { get; private set; }
        //Metodo inserir Dados na tabela
        public int InserirDados(List<Model.Model> dados)
        {
            ConnectionString = ConfigurationSettings.AppSettings["connectionString"].ToString();
            var dbConn = new SqlConnection(ConnectionString);
            try
            {
                for (int e = 0; e < dados.Count; e++)
                {
                    var dt = new DataTable();
                    dt.Columns.Add("CampoA");
                    dt.Columns.Add("CampoB");
                    dt.Columns.Add("CampoC");
                    dt.Columns.Add("CampoD");
                    dt.Columns.Add("CampoE");
                    dt.Columns.Add("CampoF");
                    dt.Rows.Add(dados[e].p_campoA, dados[e].p_campoB, dados[e].p_campoC, dados[e].p_campoD, dados[e].p_campoE, dados[e].p_campoF);
                    var Ins = new SqlBulkCopy(dbConn, SqlBulkCopyOptions.TableLock, null)
                    {
                        DestinationTableName = "Table_1",
                        BatchSize = dt.Rows.Count
                    };
                    dbConn.Open();
                    Ins.WriteToServer(dt);
                    dbConn.Close();
                    Ins.Close();
                }
            }
            catch (Exception ex)
            {
                return 0;
            }
            return 1;
        }
        //pesquisa dados na tabela
        public List<Model.Model> SelecionarDados()
        {
            Model.Model o_Dados = new Model.Model();
            List<Model.Model> l_Dados = new List<Model.Model>();
            ConnectionString = ConfigurationSettings.AppSettings["connectionString"].ToString();
            try
            {
                using (SqlConnection Con = new SqlConnection(ConnectionString))
                {
                    SqlCommand cmd = new SqlCommand("Select CampoA,CampoB,CampoC,CampoD,CampoE,CampoF From   dbo.Table_1(Nolock)", Con);
                    Con.Open();
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            o_Dados = new Model.Model();
                            o_Dados.p_campoA = rdr["CampoA"].ToString();
                            o_Dados.p_campoB = rdr["CampoB"].ToString();
                            o_Dados.p_campoC = rdr["CampoC"].ToString();
                            o_Dados.p_campoD = rdr["CampoD"].ToString();
                            o_Dados.p_campoE = rdr["CampoE"].ToString();
                            o_Dados.p_campoF = rdr["CampoF"].ToString();
                            l_Dados.Add(o_Dados);
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return l_Dados;
        }
    }
}
