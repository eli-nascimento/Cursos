using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TypeGenericCA
{
    class Program
    {
        static void Main(string[] args)
        {
  
            var macho = new Cachorro() {  Raca = "Pastor Alemão",Peso=10 };
            var femea = new Cachorro() { Raca = "Bigou", Peso = 30 };
            var filhote = CruzarCachorro(macho, femea);
            
            Console.WriteLine("Dados dos Filhotes Não genericos");
            Console.WriteLine("A raça do Pai é: " + filhote.Pai + " o peso é: " + filhote.Peso + "Kg");
            Console.WriteLine("A raça da Mãe é: " + filhote.Raca + " o peso é: " + filhote.Peso + "Kg");
            Console.WriteLine("");
            
           
            var machoGenerico = new CachorroGenerico() { Raca = "Pastor Alemão", Peso = 10 };
            var femeaGenerico = new CachorroGenerico() { Raca = "Bigou", Peso = 30 };
            var filhoteGenerico = Cruzar(machoGenerico, femeaGenerico);

            Console.WriteLine("Dados dos Filhotes genericos");
            Console.WriteLine("A raça do Pai é: " + filhoteGenerico.Pai.Raca + " o peso é: " + filhoteGenerico.Pai.Peso + "Kg");
            Console.WriteLine("A raça da Mãe é: " + filhoteGenerico.Mae.Raca + " o peso é: " + filhoteGenerico.Mae.Peso + "Kg");
            Console.ReadKey();

            // Go to http://aka.ms/dotnet-get-started-console to continue learning how to build a console app! 
        }
        //Codigo metodo original
        public static Cachorro CruzarCachorro(Cachorro macho, Cachorro femea)
        {
            var filhote = new Cachorro() { Pai = macho, Mae = femea };
            return filhote;
        }

        //Codigo metodo Generico
        public static T Cruzar<T>(T machoGenerico, T femeaGenerico) where T : MamiferoGenerico<T>
        {
            //essa linha da erro porque não pode estancia um tipo generico var filhote = new T() { Pai = macho, Mae = femea };
            var filhoteGenerico = Activator.CreateInstance<T>();

            //Sem esse item 'where T : Mamifero<T>' não aparece a propriedade no filhote 'filhoteGenerico.Mae'
            filhoteGenerico.Mae = femeaGenerico;
            filhoteGenerico.Pai = machoGenerico;
            return filhoteGenerico;
        }

    }

    #region | codigo original não generico

    public abstract class Mamifero
    {
        public Mamifero Pai { get; set; }
        public Mamifero Mae { get; set; }
        public decimal Peso { get; set; }
    }

    public class Cachorro : Mamifero
    {
        public string Raca { get; set; }
    }

    public class Gato : Mamifero
    {
        public string Raca { get; set; }
        public int Bigode { get; set; }
    }

    public class Elefante : Mamifero
    {
        public int Tromba { get; set; }
    }
 
   #endregion
    #region | codigo generico
   
    //Usando tipo generico
    //where T : Mamifero<T> - Esse codigo restrige a classe mamifero para o prorio tipo
    //Entao Cachorro vai ter um Pai e uma Mae do Tipo Cachorro 
    public abstract class MamiferoGenerico<T> where T : MamiferoGenerico<T>
    {
        public T Pai { get; set; }
        public T Mae { get; set; }
        public decimal Peso { get; set; }
    }

    //Usando tipo generico ,tipando a classe cachorro para p tipo Cachorro
    public class CachorroGenerico : MamiferoGenerico<CachorroGenerico>
    {
        public string Raca { get; set; }
    }

    //Usando tipo generico ,tipando a classe Gato para p tipo Gato
    public class GatoGenerico : MamiferoGenerico<GatoGenerico>
    {
        public string Raca { get; set; }
        public int Bigode { get; set; }
    }

    //Usando tipo generico ,tipando a classe Elefante para p tipo Elefante
    public class ElefanteGenerico : MamiferoGenerico<ElefanteGenerico>
    {
        public int Tromba { get; set; }
    }
    #endregion
}
