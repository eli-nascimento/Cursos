﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public partial class Dashboard : Form
    {
        List<Person> people = new List<Person>();

        public Dashboard()
        {
            InitializeComponent();
            UpdateBinding();
            
        }

        private void UpdateBinding()
        {
            peopleFoundListBox.DataSource = people;
            peopleFoundListBox.DisplayMember = "FullInfo";//FullInfo property da Person
        }


        private void searchButton_Click(object sender, EventArgs e)
        {
            DataAccess db = new DataAccess();

            people = db.GetPeople(lastNameText.Text);

            UpdateBinding();
           
        }

        private void insertButtton_Click(object sender, EventArgs e)
        {
            DataAccess db = new  DataAccess();
            //Digitei toda a linha e depois cliquei no nome do metodo e abre a opção para criar na classe DataAccess
            db.InsertPerson(firstNametext.Text, lastnameText2.Text, emailAddresText.Text, phoneNumberText.Text);
            firstNametext.Text = string.Empty;
            lastnameText2.Text = string.Empty;
            emailAddresText.Text = string.Empty;
            phoneNumberText.Text = string.Empty;
        }
    }
}
