﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace FormUI
{
    public class DataAccess
    {
        //Install Nuget Package Dapper for Conect SqlServer Or another database
        public List<Person> GetPeople(string lastName)
        {
            //Com using automaticamente wlw abre e fecha a conexao
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("BrqDB")))
            {
                //Não é a melhor pratica usar dessa forma porque pode causar uma falha na segurança com SqlInjection
                //var output =  connection.Query<Person>($"select * from People where LastName =  '{ lastName }'").ToList();
                //Usar StoreProcedure
                //Esse trecho ,new {LastName = lastName } é uma classe local dinamica LastName representa a variavel com paramentro de entrada
                // da Procedure @LastName e lastName é a variavel do metodo GetPeople
                var output = connection.Query<Person>("dbo.People_GetByLastName @LastName",new {LastName = lastName }).ToList();
                return output;
            }
            
        }

        public void InsertPerson(string firstName, string lastName, string emailAddress, string phoneNumber)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("BrqDB")))
            {
                //FirstName = firstName -> FirstName esta na classe Person e firstName no metodo local intellissence ja mostra a opção
                //Option 1
                //Person newPerson = new Person { FirstName = firstName,LastName=lastName,EmailAddress=emailAddress,PhoneNumber=phoneNumber };
                List<Person> people = new List<Person>();
                //Option 2
                people.Add(new Person { FirstName = firstName, LastName = lastName, EmailAddress = emailAddress, PhoneNumber = phoneNumber });
                //Comando com Stored Procedure
                connection.Execute("dbo.People_Insert @FirstName,@Lastname,@EmailAddress,@PhoneNumber", people);
            }
        }
    }
}
