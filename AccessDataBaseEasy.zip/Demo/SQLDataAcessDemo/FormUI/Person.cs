﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormUI
{
    //Obs. uteis:
    //para criar cada variavel basta digitar prop + tecla tab duas vezes
    //exs: public int MyProperty { get; set; }
    //para criar cada propriedades como  basta digitar propFull + tecla tab duas vezes
    //ex:     
    //private int myVar;
    //public int MyProperty
    //{
    //    get { return myVar; }
    //    set { myVar = value; }
    //}

    public class Person
    {
       
        public int id { get; set; }

        public string  FirstName { get; set; }

        public string LastName { get; set; }

        public string  EmailAddress { get; set; }

        public string PhoneNumber { get; set; }

        //Usar property full para incluir dados dentro do Get ou set
        public string  FullInfo
        {
            get
            {
                //Concatena as propriedades
                //"eli Nascimento (elijnascimento@gmail.com)"
                return $"{ FirstName } { LastName } ({EmailAddress})";
            }
        }


    }
}
