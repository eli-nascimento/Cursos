﻿namespace FormUI
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.peopleFoundListBox = new System.Windows.Forms.ListBox();
            this.lastNameText = new System.Windows.Forms.TextBox();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.searchButton = new System.Windows.Forms.Button();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.firstNametext = new System.Windows.Forms.TextBox();
            this.lastNameLabel2 = new System.Windows.Forms.Label();
            this.lastnameText2 = new System.Windows.Forms.TextBox();
            this.emailAdrresLabel = new System.Windows.Forms.Label();
            this.emailAddresText = new System.Windows.Forms.TextBox();
            this.phoneNumberLabel = new System.Windows.Forms.Label();
            this.phoneNumberText = new System.Windows.Forms.TextBox();
            this.insertButtton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // peopleFoundListBox
            // 
            this.peopleFoundListBox.FormattingEnabled = true;
            this.peopleFoundListBox.ItemHeight = 31;
            this.peopleFoundListBox.Location = new System.Drawing.Point(34, 111);
            this.peopleFoundListBox.Name = "peopleFoundListBox";
            this.peopleFoundListBox.Size = new System.Drawing.Size(680, 159);
            this.peopleFoundListBox.TabIndex = 0;
            // 
            // lastNameText
            // 
            this.lastNameText.Location = new System.Drawing.Point(185, 51);
            this.lastNameText.Name = "lastNameText";
            this.lastNameText.Size = new System.Drawing.Size(169, 38);
            this.lastNameText.TabIndex = 1;
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(28, 51);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(151, 32);
            this.lastNameLabel.TabIndex = 2;
            this.lastNameLabel.Text = "Last Name";
            // 
            // searchButton
            // 
            this.searchButton.Location = new System.Drawing.Point(736, 111);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(181, 44);
            this.searchButton.TabIndex = 3;
            this.searchButton.Text = "Search";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(28, 306);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(152, 32);
            this.firstNameLabel.TabIndex = 5;
            this.firstNameLabel.Text = "First Name";
            // 
            // firstNametext
            // 
            this.firstNametext.Location = new System.Drawing.Point(239, 300);
            this.firstNametext.Name = "firstNametext";
            this.firstNametext.Size = new System.Drawing.Size(169, 38);
            this.firstNametext.TabIndex = 4;
            // 
            // lastNameLabel2
            // 
            this.lastNameLabel2.AutoSize = true;
            this.lastNameLabel2.Location = new System.Drawing.Point(28, 364);
            this.lastNameLabel2.Name = "lastNameLabel2";
            this.lastNameLabel2.Size = new System.Drawing.Size(151, 32);
            this.lastNameLabel2.TabIndex = 7;
            this.lastNameLabel2.Text = "Last Name";
            // 
            // lastnameText2
            // 
            this.lastnameText2.Location = new System.Drawing.Point(239, 358);
            this.lastnameText2.Name = "lastnameText2";
            this.lastnameText2.Size = new System.Drawing.Size(169, 38);
            this.lastnameText2.TabIndex = 6;
            // 
            // emailAdrresLabel
            // 
            this.emailAdrresLabel.AutoSize = true;
            this.emailAdrresLabel.Location = new System.Drawing.Point(28, 422);
            this.emailAdrresLabel.Name = "emailAdrresLabel";
            this.emailAdrresLabel.Size = new System.Drawing.Size(198, 32);
            this.emailAdrresLabel.TabIndex = 9;
            this.emailAdrresLabel.Text = "Email Address";
            // 
            // emailAddresText
            // 
            this.emailAddresText.Location = new System.Drawing.Point(239, 416);
            this.emailAddresText.Name = "emailAddresText";
            this.emailAddresText.Size = new System.Drawing.Size(169, 38);
            this.emailAddresText.TabIndex = 8;
            // 
            // phoneNumberLabel
            // 
            this.phoneNumberLabel.AutoSize = true;
            this.phoneNumberLabel.Location = new System.Drawing.Point(28, 480);
            this.phoneNumberLabel.Name = "phoneNumberLabel";
            this.phoneNumberLabel.Size = new System.Drawing.Size(205, 32);
            this.phoneNumberLabel.TabIndex = 11;
            this.phoneNumberLabel.Text = "Phone Number";
            // 
            // phoneNumberText
            // 
            this.phoneNumberText.Location = new System.Drawing.Point(239, 474);
            this.phoneNumberText.Name = "phoneNumberText";
            this.phoneNumberText.Size = new System.Drawing.Size(169, 38);
            this.phoneNumberText.TabIndex = 10;
            // 
            // insertButtton
            // 
            this.insertButtton.Location = new System.Drawing.Point(511, 375);
            this.insertButtton.Name = "insertButtton";
            this.insertButtton.Size = new System.Drawing.Size(181, 44);
            this.insertButtton.TabIndex = 12;
            this.insertButtton.Text = "Insert";
            this.insertButtton.UseVisualStyleBackColor = true;
            this.insertButtton.Click += new System.EventHandler(this.insertButtton_Click);
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(949, 530);
            this.Controls.Add(this.insertButtton);
            this.Controls.Add(this.phoneNumberLabel);
            this.Controls.Add(this.phoneNumberText);
            this.Controls.Add(this.emailAdrresLabel);
            this.Controls.Add(this.emailAddresText);
            this.Controls.Add(this.lastNameLabel2);
            this.Controls.Add(this.lastnameText2);
            this.Controls.Add(this.firstNameLabel);
            this.Controls.Add(this.firstNametext);
            this.Controls.Add(this.searchButton);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.lastNameText);
            this.Controls.Add(this.peopleFoundListBox);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Dashboard";
            this.Text = "SQL Data Acess Demo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox peopleFoundListBox;
        private System.Windows.Forms.TextBox lastNameText;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.TextBox firstNametext;
        private System.Windows.Forms.Label lastNameLabel2;
        private System.Windows.Forms.TextBox lastnameText2;
        private System.Windows.Forms.Label emailAdrresLabel;
        private System.Windows.Forms.TextBox emailAddresText;
        private System.Windows.Forms.Label phoneNumberLabel;
        private System.Windows.Forms.TextBox phoneNumberText;
        private System.Windows.Forms.Button insertButtton;
    }
}

