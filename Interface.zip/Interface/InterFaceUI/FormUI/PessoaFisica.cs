﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace FormUI
{
    public class PessoaFisica : IConnect
    {
        public bool Conectar()
        {
            throw new NotImplementedException();
        }

        public bool Desconectar()
        {
            throw new NotImplementedException();
        }

        public DataTable TabelaRetorno()
        {
            throw new NotImplementedException();
        }

        public void vDelete()
        {
            throw new NotImplementedException();
        }

        public void vInsert()
        {
            throw new NotImplementedException();
        }

        public void vUpdate()
        {
            throw new NotImplementedException();
        }
    }
}
