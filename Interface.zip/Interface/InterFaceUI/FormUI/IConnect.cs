﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace FormUI
{
    interface IConnect
    {
        //Metodos  //Propriedades //Indexadores //Eventos 

        bool Conectar();
        bool Desconectar();
        DataTable TabelaRetorno();

        void vInsert();

        void vUpdate();

        void vDelete();


    }
}
