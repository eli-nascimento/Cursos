﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppClasseIndexadors
{

    //Neste programa criamos  uma classe Time com um indexador definido.
    //A classe Time contém um indexador que possui um método com get para obter valores e set para atribuir valores.
    //Os acessores (get e set) possuem a lógica que assegura que o array não será acessado fora dos seus limites(10 elementos).
    //O programa exibe os 4 primeiros elementos válidos da classe Time, um valor inválido(null) e também o resultado de um acesso inválido. (Erro)
    //O recurso indexadores era muito usado antes da introdução das coleções Generics.
    //Observe que você tem que implementar a função que acessa e atribui valores ao item.

    class Program
    {
        static void Main(string[] args)
        {
            // Cria uma instância da classe Time e atribui elementos
            // ... no array através dos indexadores
            Time time = new Time();
            time[1] = "Palmeiras";
            time[3] = "Santos";
            time[5] = "São Paulo";
            time[7] = "Corintians";
            time[-1] = "Flamento";
            time[1000] = "Erro";
            // Le os elementos usando os indexadores
            string valor1 = time[1];
            string valor2 = time[3];
            string valor3 = time[5];
            string valor4 = time[7];
            string valor5 = time[9];
            string valor6 = time[-1];
            // Escreve o resultado
            Console.WriteLine(valor1);
            Console.WriteLine(valor2);
            Console.WriteLine(valor3);
            Console.WriteLine(valor4);
            Console.WriteLine(valor5); // É null
            Console.WriteLine(valor6);
            Console.ReadKey();
        }
    }
}
