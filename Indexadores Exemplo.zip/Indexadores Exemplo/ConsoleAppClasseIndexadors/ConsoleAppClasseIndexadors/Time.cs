﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppClasseIndexadors
{
    public class Time
    {
        string[] _valores = new string[10]; //define os limites do array
        public string this[int numero]
        {
            get
            {
                // Será invocado quando acessarmos instâncias da classe Time com []
                if (numero >= 0 && numero < _valores.Length)
                {
                    // retorna o valor armazenado
                    return _valores[numero];
                }
                // Retorna um erro
                return "Erro";
            }
            set
            {
                // Será invocado quando atribuímos valores a instâncias de Time com []
                if (numero >= 0 && numero < _valores.Length)
                {
                    // atribui valor ao elemento
                    _valores[numero] = value;
                }
            }
        }
    }
}
