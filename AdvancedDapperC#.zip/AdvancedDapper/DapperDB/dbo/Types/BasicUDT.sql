﻿CREATE TYPE [dbo].[BasicUDT] AS TABLE
(
	FirstName NVARCHAR(50),
	LastName NVARCHAR(50)
)
