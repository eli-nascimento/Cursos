using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Reflection;


namespace ReflectionCA
{
    class Program
    {
        static void Main(string[] args)
        {
            var pessoa = new Pessoa() { Nome = "João", Idade = 20 };
            var equipamento = new Equipamento() { Descricao = "Chave de Fenda", Modelo = "F20", Marca = "Tramotina" };
            var livro = new Livro() { Titulo = "Harry Pootter", Lancamento = new DateTime(1996, 6, 26) };
        }
    }
    public void LogPessoa(Pessoa pessoa)
    {
        var builder = new StringBuilder();
        builder.AppendLine("Data do log:" + DateTime.Now);
        builder.AppendLine("Nome:" + pessoa.Nome);
        builder.AppendLine("Idade:" + pessoa.Idade);
        builder.AppendLine("Nacionalidade:" + pessoa.Nacionalidade);
        builder.ToString();

    }
    public class Pessoa
    {

        public string Nome { get; set; }
        public int Idade { get; set; }
        public string Nacionalidade { get; set; }

    }

    public class Equipamento
    {
        public string Descricao { get; set; }
        public string Modelo { get; set; }
        public string Marca { get; set; }
    }

    public class Livro
    {
        public string Titulo { get; set; }
        public DateTime Lancamento { get; set; }
    }
}
