﻿namespace ClassLibraryDemo
{
    //Existe uma configuração no projeto que defini para quais assemblies os objetos configurados como internal serão visíveis.Para configurar isso, precisaremos ir no AssemblyInfo.cs do nosso class library e adicionar a seguinte linha:
    //[assembly: InternalsVisibleTo("ClassLibraryTestDemo")]
    internal class LivroService
    {
        internal int CalculaExemplares(int numeroDeCaixas, int quantidadeDeLivrosPorCaixa)
        {
            //exemplo
            return numeroDeCaixas * quantidadeDeLivrosPorCaixa;
        }
        private double CalculaPesoDaCaixa(double pesoLivro, int quantidadeDeLivros)
        {
            //exemplo
            return pesoLivro * quantidadeDeLivros;
        }

        protected double CalculaPesoDaCaixaComACaixa(double pesoLivro, double pesoCaixa, int quantidadeDeLivros)
        {
            //exemplo
            return (pesoLivro * quantidadeDeLivros) + pesoCaixa;
        }
    }
}
