﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Reflection;
using ClassLibraryDemo;

namespace CalculaPesoDaCaixaUT
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Verifica_Se_2_Livros_De_200_Gramas_Pesam_400_Gramas()
        {
            const int numeroDeLivros = 2;
            const double pesoDeCadaLivro = 0.2;
            var livroService = new LivroService();
            var bindingFlags = BindingFlags.Instance | BindingFlags.NonPublic;
            MethodInfo mInfoMethod = typeof(LivroService).GetMethod("CalculaPesoDaCaixa", bindingFlags);
            var pesoTotal = (double)mInfoMethod.Invoke(livroService, new object[] { pesoDeCadaLivro, numeroDeLivros });
            Assert.AreEqual(0.4, pesoTotal);
        }

        // Existem diversas maneiras de acessar e trabalhar com métodos que estão 
        //configurados como private, no exemplo abaixo utilizei Reflection para acessar e implementar um teste para validar método CalculaPesoDaCaixa.
        [TestMethod]
        public void Verifica_Se_2_Livros_De_300_Gramas_Com_Uma_Caixa_De_100_Gramas_Pesam_700_Gramas()
        {
            const int numeroDeLivros = 2;
            const double pesoDeCadaLivro = 0.3;
            const double pesoDaCaixa = 0.1;
            var livroService = new LivroService();
            var bindingFlags = BindingFlags.Instance | BindingFlags.NonPublic;
            MethodInfo mInfoMethod = typeof(LivroService).GetMethod("CalculaPesoDaCaixaComACaixa", bindingFlags);
            var pesoTotal = (double)mInfoMethod.Invoke(livroService, new object[] { pesoDeCadaLivro, pesoDaCaixa, numeroDeLivros });
            Assert.AreEqual(0.7, pesoTotal);
        }


        //Da mesma maneira que utilizamos Reflection para testar o método privado, podemos utilizar ele para testar um método configurado como protected, abaixo eu testo o CalculaPesoDaCaixaComACaixa utilizando Reflection.
        [TestMethod]
         public void Verifica_Se_2_Livros_De_300_Gramas_Com_Uma_Caixa_De_100_Gramas_Pesam_800_Gramas()
        {
            const int numeroDeLivros = 2;
            const double pesoDeCadaLivro = 0.3;
            const double pesoDaCaixa = 0.1;
            var livroService = new LivroService();
            var bindingFlags = BindingFlags.Instance | BindingFlags.NonPublic;
            MethodInfo mInfoMethod = typeof(LivroService).GetMethod("CalculaPesoDaCaixaComACaixa", bindingFlags);
            var pesoTotal = (double)mInfoMethod.Invoke(livroService, new object[] { pesoDeCadaLivro, pesoDaCaixa, numeroDeLivros });
            Assert.AreEqual(0.7, pesoTotal);
        }
    }
}
