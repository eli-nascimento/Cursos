# BoasPraticasLinqEntityFramework
Boas Práticas LINQ entity Framework
