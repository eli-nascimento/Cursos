﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComposicaoInterfaceHerancaComposicao
{
    class Program
    {
        //Opcao 1 Vai receber sempre o mesmo Dad e a mesma Mon
        //static void Main(string[] args)
        //{

        //    var son = new Son(new Dad(), new Mon()); 

        //}

        //Opcao 2 Não vai receber sempre o mesmo Dad e a mesma Mon
        static void Main(string[] args)
        {
            var dad = new Dad();
            var mon = new Mon();

            //Varios Filhos
            var son = new Son(dad,mon);
            var son2 = new Son(dad, mon);

            //Outro tipo Dad/Mon
            var son3 = new Son(new Dad2(), new Mon2());
        }
    }
}
