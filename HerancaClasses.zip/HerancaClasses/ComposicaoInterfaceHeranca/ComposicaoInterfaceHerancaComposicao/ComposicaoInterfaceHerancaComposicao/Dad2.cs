﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComposicaoInterfaceHerancaComposicao
{
    public class Dad2 : IDad
    {
        public int Height { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public int Strength { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }
}
