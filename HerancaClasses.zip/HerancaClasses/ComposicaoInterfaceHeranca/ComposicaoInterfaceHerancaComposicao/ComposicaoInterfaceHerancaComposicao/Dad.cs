﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComposicaoInterfaceHerancaComposicao
{
    ////Opção 1
    //public class Dad
    //{
    //    public int Height { get; set; }
    //    public int Strength { get; set; }
    //}

    //Opção 2
    public class Dad:IDad
    {
        public int Height { get; set; }
        public int Strength { get; set; }
    }
}
