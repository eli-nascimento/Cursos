﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComposicaoInterfaceHerancaComposicao
{
    //Opção 1
    //public class Mon
    //{
    //    public int Height { get; set; }
    //    public int Weigth { get; set; }
    //}

    //Opção 2
    public class Mon:IMon
    {
        public int Height { get; set; }
        public int Weigth { get; set; }
    }
}
