﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComposicaoInterfaceHerancaComposicao
{

    //Objetivo é a classe Son herdar class Dad e Mon Simultaneamente
    //CSharp não permite herdar duas classe o melhor é usa composicao de interface + classe
    // Melhor utilizar composição e vez da herança

    //primeira opção implementar interface não é o conceito de herança
    //public class Son : IDad, IMon
    //{
    //    public int Height { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    //    public int Strength { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    //    public int Weigth { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    //}

    //Opcao 1 Vai receber sempre o mesmo Dad e a mesma Mon
    //public class Son
    //{
    //    public Dad Dad { get; set; }
    //    public Mon Mon { get; set; }

    //    //Construtor

    //    public Son(Dad dad,Mon mon)
    //    {
    //        Dad = dad;
    //        Mon = mon;
    //    }
    //}

    //Opcao 2 Não vai receber sempre o mesmo Dad e a mesma Mon
    public class Son :IDad,IMon
    {
        public IDad Dad { get; set; }
        public IMon Mon { get; set; }
       

        //Construtor

        public Son(IDad dad, IMon mon)
        {
            Dad = dad;
            Mon = mon;
        }

        public int Height
        {
            get { return Dad.Height; }
            set { }
        }
        public int Strength
        {
            get { return Dad.Strength; }
            set { }
        }
        public int Weigth
        {
           get { return Mon.Weigth; }
            set { }
        }
    }
}
