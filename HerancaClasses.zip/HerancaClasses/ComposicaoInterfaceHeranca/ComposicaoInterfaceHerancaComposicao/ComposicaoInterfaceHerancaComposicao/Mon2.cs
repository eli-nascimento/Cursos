﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComposicaoInterfaceHerancaComposicao
{
    public class Mon2 : IMon
    {
        public int Height { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public int Weigth { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }
}
