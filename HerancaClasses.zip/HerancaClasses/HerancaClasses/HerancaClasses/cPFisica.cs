﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HerancaClasses
{
    public class cPFisica:cPBase
    {
        public string cpf { get; set; }
        public string mAniversario { get; set; }
    }
}
