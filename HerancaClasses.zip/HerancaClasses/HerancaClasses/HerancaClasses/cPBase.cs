﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HerancaClasses
{
   public class cPBase
    {
        public string  nome { get; set; }
        public string  cidade { get; set; }
        public string  uf { get; set; }
        public  int nFilhos { get; set; }
        public int idade { get; set; }

        public void insert() { }
    }
}
