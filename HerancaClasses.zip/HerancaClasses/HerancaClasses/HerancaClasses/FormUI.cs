﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HerancaClasses
{
    public partial class FormUI : Form
    {
        public FormUI()
        {
            InitializeComponent();
        }

        private void FormUI_Load(object sender, EventArgs e)
        {

        }

        public void pFisica()
        {
            //Aqui tenho acesso as propriedade da classe basica + fisica
            cPFisica objFisica = new cPFisica();

            objFisica.cidade = "São Paulo";
            objFisica.cpf = "000.000.000-00";
            objFisica.idade = 20;
            objFisica.mAniversario = "04";
            objFisica.nFilhos = 12;
            objFisica.nome = "Antonio dos Santos";
            objFisica.uf = "SP";
            //Acesso só metodo da classe base
            objFisica.insert();

        }

        public void pJuridica()
        {
            //Aqui tenho acesso as propriedade da classe basica + juridica
            cPJuridica objJuridica = new cPJuridica();

            objJuridica.cidade = "";
            objJuridica.cnpj = "";
            objJuridica.idade = 0;
            objJuridica.nFilhos = 0;
            objJuridica.nFuncionarios = "0";
            objJuridica.nome = "";
            objJuridica.rsocial = "";
            //Acesso o metodo da classe basica
            objJuridica.insert();
            //acesso o metod da classe Juridica
            objJuridica.upCnpj();
        }
    }
}
