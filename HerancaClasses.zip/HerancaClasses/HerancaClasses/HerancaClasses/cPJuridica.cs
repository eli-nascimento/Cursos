﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HerancaClasses
{
    public  class cPJuridica :cPBase
    {
        public string  cnpj { get; set; }
        public string rsocial { get; set; }
        public string nFuncionarios { get; set; }

        public void upCnpj() { }
    }
}
