﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;


namespace ClasseAbstrataComBeep
{

 

    public partial class FormUI : Form
    {
        [DllImport("Kernel32.dll")]
        public static extern bool Beep(UInt32 frenquency, UInt32 duration);

        //Uma classe abstrata é uma classe que não pode ser instanciada Forma f = new Forma(). Você não pode criar um objeto a partir de uma classe abstrata.
        //Uma classe abstrata pode ser herdada e geralmente serve como classe base para outras classes.
        //Uma classe abstrata pode conter métodos abstratos e métodos comuns. Uma classe abstrata também podem possuir construtores, propriedades, indexadores e eventos.
        //Uma classe abstrata não pode ser estática(static). Uma classe abstrata não pode ser selada(sealed).
        //Uma classe abstrata pode herdar de outra classe abstrata.
        public abstract class Campainha
        {
            //Um método abstrato é um método que não possui implementação na classe abstrata.Um método abstrato possui somente a definição de sua assinatura.A sua implementação deve ser feita na classe derivada.
            //Um método abstrato é um método virtual e deve ser implementado usando o modificador override.
            //Um método abstrato somente pode existir em uma classe abstrata.
            //Um método abstrato não pode usar os modificadores static e virtual. 

            public abstract void Musica();

            public void Soar()
            {
                Musica();
            }
        }

        public class Campainha1 : Campainha
        {
            public override void Musica()
            {
                Beep(500, 200);
                Beep(1000, 200);
                Beep(500, 300);
                Beep(1000, 200);
            }
        }

        public class Campainha2 : Campainha
        {
            //Observe que utilizamos o modificador override para implementar
            //os métodos abstratos
            public override void Musica()
            {
                Beep(1000, 300);
                Beep(1000, 200);
                Beep(700, 300);
                Beep(1200, 500);
            }
        }
        //Então resumindo temos que:(http://pt.wikipedia.org/wiki/)

        //A classe abstrata é sempre uma superclasse que não possui instâncias;
        //Ela define um modelo para uma funcionalidade e fornece uma implementação incompleta - a parte genérica dessa funcionalidade - que é compartilhada por um grupo de classes derivadas;
        //Cada uma das classes derivadas completa a funcionalidade da classe abstrata adicionando um comportamento específico;
        //Uma classe abstrata geralmente possui métodos abstratos;
        //Esses métodos são implementados nas suas classes derivadas concretas com o objetivo de definir o comportamento específico;
        //O método abstrato define apenas a assinatura do método e, portanto, não contém código;
        public FormUI()
        {
            InitializeComponent();
        }

        private void Soar1Button_Click(object sender, EventArgs e)
        {
            Campainha camp1 = new Campainha1();
            camp1.Soar();
        }

        private void Soar2Button_Click(object sender, EventArgs e)
        {
            Campainha camp2 = new Campainha2();
            camp2.Soar();
        }

        private void FormUI_Load(object sender, EventArgs e)
        {
            textBox1.Text = "A classe abstrata é sempre uma superclasse que não possui instâncias;Ela define um modelo para uma funcionalidade e fornece uma implementação incompleta - a parte genérica dessa funcionalidade - que é compartilhada por um grupo de classes derivadas;Cada uma das classes derivadas completa a funcionalidade da classe abstrata adicionando um comportamento específico;Uma classe abstrata geralmente possui métodos abstratos;" +
                "Esses métodos são implementados nas suas classes derivadas concretas com o objetivo de definir o comportamento específico;O método abstrato define apenas a assinatura do método e, portanto, não contém código";
        }
    }
}
