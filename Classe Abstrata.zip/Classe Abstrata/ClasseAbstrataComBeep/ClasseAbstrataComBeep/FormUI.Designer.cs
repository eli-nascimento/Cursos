﻿namespace ClasseAbstrataComBeep
{
    partial class FormUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Soar1Button = new System.Windows.Forms.Button();
            this.Soar2Button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Soar1Button
            // 
            this.Soar1Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Soar1Button.Location = new System.Drawing.Point(743, 81);
            this.Soar1Button.Name = "Soar1Button";
            this.Soar1Button.Size = new System.Drawing.Size(151, 34);
            this.Soar1Button.TabIndex = 0;
            this.Soar1Button.Text = "Soar Campainha 1";
            this.Soar1Button.UseVisualStyleBackColor = true;
            this.Soar1Button.Click += new System.EventHandler(this.Soar1Button_Click);
            // 
            // Soar2Button
            // 
            this.Soar2Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Soar2Button.Location = new System.Drawing.Point(743, 121);
            this.Soar2Button.Name = "Soar2Button";
            this.Soar2Button.Size = new System.Drawing.Size(151, 35);
            this.Soar2Button.TabIndex = 1;
            this.Soar2Button.Text = "Soar Campainha 2";
            this.Soar2Button.UseVisualStyleBackColor = true;
            this.Soar2Button.Click += new System.EventHandler(this.Soar2Button_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(42, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 29);
            this.label1.TabIndex = 2;
            this.label1.Text = "Definição";
            // 
            // textBox1
            // 
            this.textBox1.AutoCompleteCustomSource.AddRange(new string[] {
            "A classe abstrata é sempre uma superclasse que não possui instâncias;",
            "Ela define um modelo para uma funcionalidade e fornece uma implementação incomple" +
                "ta - a parte genérica dessa funcionalidade - que é compartilhada por um grupo de" +
                " classes derivadas;"});
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(45, 81);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(692, 260);
            this.textBox1.TabIndex = 3;
            // 
            // FormUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(923, 388);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Soar2Button);
            this.Controls.Add(this.Soar1Button);
            this.Name = "FormUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SuperClasses ou Classes Abstratas";
            this.Load += new System.EventHandler(this.FormUI_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Soar1Button;
        private System.Windows.Forms.Button Soar2Button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
    }
}

